import CanvasManager from './module/entities/CanvasManager.js';
import ToolsManager from './module/entities/toolManager.js';
import BrushesOptionsManager from './module/entities/brushesOptionManager.js';
import FileOptionsManager from './module/entities/fileManager.js';

document.addEventListener("DOMContentLoaded", function () {
    const canvasElement = document.getElementById("canvas");
    const ctx = canvasElement.getContext('2d');

    const canvasManager = new CanvasManager(canvasElement, ctx);
    const toolsManager = new ToolsManager(canvasManager);
    const brushesOptionsManager = new BrushesOptionsManager(canvasManager);
    const fileOptionsManager = new FileOptionsManager(canvasElement, ctx);
});
