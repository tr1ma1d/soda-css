class BrushesOptionsManager {
    constructor(canvasManager) {
        this.canvasManager = canvasManager;
        this.increaseSizeButton = document.getElementById("increaseSize");
        this.decreaseSizeButton = document.getElementById("decreaseSize");
        this.textBoxSize = document.getElementById('textbox_option');
        this.brushSizeDisplay = document.getElementById("brushSize");

        this.init();
    }

    init() {
        this.increaseSizeButton.addEventListener("click", () => this.changeBrushSize(1));
        this.decreaseSizeButton.addEventListener("click", () => this.changeBrushSize(-1));
        this.textBoxSize.addEventListener("input", () => this.updateBrushSizeFromText());

        this.updateBrushSizeDisplay();
    }

    changeBrushSize(delta) {
        this.canvasManager.brushSize = Math.max(1, this.canvasManager.brushSize + delta);
        this.updateBrushSizeDisplay();
    }

    updateBrushSizeFromText() {
        let newSize = parseInt(this.textBoxSize.value, 10);
        if (!isNaN(newSize) && newSize > 0) {
            this.canvasManager.brushSize = newSize;
            this.updateBrushSizeDisplay();
        }
    }

    updateBrushSizeDisplay() {
        this.brushSizeDisplay.innerText = `Размер кисти: ${this.canvasManager.brushSize}`;
        this.textBoxSize.value = `${this.canvasManager.brushSize}`;
    }
}
export default BrushesOptionsManager;