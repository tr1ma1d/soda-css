class CanvasManager {
    constructor(canvas, ctx) {
        this.canvas = canvas;
        this.ctx = ctx;
        this.pos = { x: 0, y: 0 };
        this.currentTool = '';
        this.canDraw = false;
        this.currentColor = '#c0392b';
        this.brushSize = 10;

        this.init();
    }

    init() {
        document.body.style.margin = 0;
        this.resizeCanvas();

        window.addEventListener('resize', () => this.resizeCanvas());
        document.addEventListener('mousemove', (e) => this.draw(e));
        document.addEventListener('mousedown', (e) => this.setPosition(e));
        document.addEventListener('mouseenter', (e) => this.setPosition(e));
    }

    resizeCanvas() {
        let scaleFactor = window.devicePixelRatio;
        this.ctx.canvas.width = Math.floor(this.canvas.offsetWidth / scaleFactor);
        this.ctx.canvas.height = Math.floor(this.canvas.offsetHeight / scaleFactor);
    }

    setPosition(e) {
        this.pos.x = e.clientX - this.canvas.getBoundingClientRect().left - this.canvas.width / 2;
        this.pos.y = e.clientY - this.canvas.getBoundingClientRect().top - this.canvas.height / 2;
    }

    draw(e) {
        if (!this.canDraw || e.buttons !== 1) return;

        this.ctx.beginPath();

        if (this.currentTool === 'brush') {
            this.ctx.lineWidth = this.brushSize;
            this.ctx.lineCap = 'round';
            this.ctx.strokeStyle = this.currentColor;
        } else if (this.currentTool === 'eraser') {
            this.ctx.lineWidth = this.brushSize + 10;
            this.ctx.lineCap = 'round';
            this.ctx.strokeStyle = '#ffffff';
        } else if(this.currentTool === 'fill-drip'){
            this.ctx.lineWidth = this.brushSize + 80000;
            this.ctx.lineCap = 'round';
            this.ctx.strokeStyle = this.currentColor;
        }


        this.ctx.moveTo(this.pos.x + this.canvas.width / 2, this.pos.y + this.canvas.height / 2);
        this.setPosition(e);
        this.ctx.lineTo(this.pos.x + this.canvas.width / 2, this.pos.y + this.canvas.height / 2);

        this.ctx.stroke();
    }
    
}
export default CanvasManager;