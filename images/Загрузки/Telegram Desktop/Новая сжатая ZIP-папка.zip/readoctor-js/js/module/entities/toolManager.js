class ToolsManager {
    constructor(canvasManager) {
        this.canvasManager = canvasManager;
        this.brushButton = document.getElementById("brush");
        this.eraserButton = document.getElementById("eraser");
        this.colorsButton = document.getElementById("colors");
        this.fillDripButton = document.getElementById("fill-drip");
        this.colorPicker = document.getElementById("colorPicker");

        this.init();
    }

    init() {
        this.brushButton.addEventListener("click", () => this.selectTool('brush', this.brushButton));
        this.eraserButton.addEventListener("click", () => this.selectTool('eraser', this.eraserButton));
        this.fillDripButton.addEventListener('click', () => this.selectTool('fill-drip', this.fillDripButton));

        this.colorsButton.addEventListener("click", () => this.colorPicker.click());

        this.colorPicker.addEventListener("input", () => {
            this.canvasManager.currentColor = this.colorPicker.value;
        });
    }

    selectTool(tool, button) {
        this.resetButtonColors();
        if (button.style.backgroundColor === "gray") {
            button.style.backgroundColor = "white";
            this.canvasManager.canDraw = false;
        } else {
            button.style.backgroundColor = "gray";
            document.getElementById('brushes-option').style.opacity = '1';
            this.canvasManager.currentTool = tool;
            this.canvasManager.canDraw = true;
            this.canvasManager.canvas.style.cursor = `url("${tool}-cursor.png"), auto`;
        }
    }

    resetButtonColors() {
        this.brushButton.style.backgroundColor = "white";
        this.eraserButton.style.backgroundColor = "white";
        this.colorsButton.style.backgroundColor = "white";
        this.fillDripButton.style.backgroundColor = "white";
    }





}


export default ToolsManager;