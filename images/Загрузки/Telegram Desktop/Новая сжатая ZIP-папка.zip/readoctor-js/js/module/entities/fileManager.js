class FileOptionsManager {

    
    constructor(canvas, ctx) {
        this.canvas = canvas;
        this.ctx = ctx;
        this.uploadButton = document.getElementById('upload-btn');
        this.uploadInput = document.getElementById('upload');
        this.saveButton = document.getElementById('save-btn');

        this.init();
    }

    init() {
        this.uploadButton.addEventListener('click', () => this.uploadInput.click());
        this.uploadInput.addEventListener('change', (e) => this.uploadFile(e));
        this.saveButton.addEventListener('click', () => this.saveCanvas());
    }

    uploadFile(e) {
        const file = e.target.files[0];
        const reader = new FileReader();

        reader.onload = (event) => {
            const img = new Image();
            img.onload = () => {
                this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
                this.ctx.drawImage(img, 0, 0, this.canvas.width, this.canvas.height);
            };
            img.src = event.target.result;
        };

        if (file) {
            reader.readAsDataURL(file);
        }
    }

    saveCanvas() {
        const link = document.createElement('a');
        link.download = 'canvas-image.png';
        link.href = this.canvas.toDataURL();
        link.click();
    }
}


export default FileOptionsManager;