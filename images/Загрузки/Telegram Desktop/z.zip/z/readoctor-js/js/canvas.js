document.addEventListener("DOMContentLoaded", function () {
    const canvas = document.getElementById("canvas");
    const ctx = canvas.getContext('2d');
    const brushButton = document.getElementById("brush");
    const eraserButton = document.getElementById("eraser");
    const colorsButton = document.getElementById("colors");

    let currentTool = ''; // Default tool is none
    let canDraw = false; // Drawing is not allowed initially

    document.body.style.margin = 0;
    resize();

    // Last known position
    var pos = { x: 0, y: 0 };

    window.addEventListener('resize', resize);
    document.addEventListener('mousemove', draw);
    document.addEventListener('mousedown', setPosition);
    document.addEventListener('mouseenter', setPosition);

    // New position from mouse event
    function setPosition(e) {
        pos.x = e.clientX - canvas.getBoundingClientRect().left - canvas.width / 2;
        pos.y = e.clientY - canvas.getBoundingClientRect().top - canvas.height / 2;
    }

    // Resize canvas
    function resize() {
        let scaleFactor = window.devicePixelRatio;
        ctx.canvas.width = Math.floor(canvas.offsetWidth / scaleFactor);
        ctx.canvas.height = Math.floor(canvas.offsetHeight / scaleFactor);
    }

    // Draw on canvas
    function draw(e) {
        // If drawing is not allowed or mouse left button is not pressed, return
        if (!canDraw || e.buttons !== 1) return;

        ctx.beginPath(); // Begin

        if (currentTool === 'brush') {
            ctx.lineWidth = 10;
            ctx.lineCap = 'round';
            ctx.strokeStyle = '#c0392b';
        } else if (currentTool === 'eraser') {
            ctx.lineWidth = 20;
            ctx.lineCap = 'round';
            ctx.strokeStyle = '#ffffff';
        }

        ctx.moveTo(pos.x + canvas.width / 2, pos.y + canvas.height / 2); // From
        setPosition(e);
        ctx.lineTo(pos.x + canvas.width / 2, pos.y + canvas.height / 2); // To

        ctx.stroke(); // Draw it!
    }

    function resetButtonColors() {
        brushButton.style.backgroundColor = "white";
        eraserButton.style.backgroundColor = "white";
        colorsButton.style.backgroundColor = "white";
    }

    brushButton.addEventListener("click", function () {
        resetButtonColors();
        if (brushButton.style.backgroundColor === "gray") {
            brushButton.style.backgroundColor = "white";
            canDraw = false;
        } else {
            brushButton.style.backgroundColor = "gray";
            currentTool = 'brush';
            canDraw = true; // Enable drawing
            canvas.style.cursor = 'url("brush-cursor.png"), auto'; // Replace with your custom cursor URL
        }
    });

    eraserButton.addEventListener("click", function () {
        resetButtonColors();
        if (eraserButton.style.backgroundColor === "gray") {
            eraserButton.style.backgroundColor = "white";
            canDraw = false;
        } else {
            eraserButton.style.backgroundColor = "gray";
            currentTool = 'eraser';
            canDraw = true; // Enable drawing
            canvas.style.cursor = 'url("eraser-cursor.png"), auto'; // Replace with your custom cursor URL
        }
    });

    colorsButton.addEventListener("click", function () {
        resetButtonColors();
        if (colorsButton.style.backgroundColor === "gray") {
            colorsButton.style.backgroundColor = "white";
            canDraw = false;
        } else {
            colorsButton.style.backgroundColor = "gray";
            currentTool = 'colors';
            canDraw = false; // Disable drawing as colors button does not draw
            canvas.style.cursor = 'default';
        }
    });
});