// product_view.dart
import 'package:flutter/material.dart';
import 'package:internet_market/shopModules/models/entities/product.dart';
import 'package:internet_market/shopModules/models/shoppingcart_model.dart';
import 'package:internet_market/shopModules/shopping_cart_page.dart';
import 'package:provider/provider.dart';
import 'dart:developer';

class ProductDetailPage extends StatefulWidget {
  final Product product;

  const ProductDetailPage({Key? key, required this.product}) : super(key: key);

  @override
  _ProductDetailPageState createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  ShoppingCartModel shoppingCartModel = ShoppingCartModel();
  bool isAddedToCart = false;

  void addToCart() {
    setState(() {
      isAddedToCart = true;
    });
    Provider.of<ShoppingCartModel>(context, listen: false).addItem(widget.product);
    log(widget.product.toString());
    log(shoppingCartModel.items[0].toString());
  }

  List<Widget> buildActions(BuildContext context) {
    return [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: FloatingActionButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ShoppingCartPage(),
              ),
            );
          },
          child: const Icon(Icons.shopping_cart),
        ),
      ),
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Consumer<ShoppingCartModel>(
          builder: (context, cart, child) {
            return Text(
              cart.items.length.toString(),
              style: Theme.of(context).textTheme.bodyLarge,
            );
          },
        ),
      ),
    ];
  }


  Widget buildItem(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (widget.product.imageUrl != null &&
              widget.product.imageUrl!.isNotEmpty)
            Image.network(
              widget.product.imageUrl!,
              height: 200.0,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          const SizedBox(height: 20.0),
          Text(
            widget.product.title!,
            style: const TextStyle(fontSize: 24.0),
          ),
          const SizedBox(height: 20.0),
          Text(
            '${widget.product.price} руб.',
            style: const TextStyle(fontSize: 18.0, color: Colors.grey),
          ),
        ],
      ),
    );
  }
 
 
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(widget.product.title ?? 'Product Detail'),
        actions: buildActions(context),
      ),
      body: buildItem(context),
      bottomNavigationBar: buildFooter().first,
    );
  }

  List<Widget> buildFooter() {
    return [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        alignment: Alignment.center,
        height: 50,
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.shopping_cart),
            const SizedBox(width: 8.0),
            ElevatedButton(
              onPressed: addToCart,
              child: Text(
                isAddedToCart ? 'Добавлено' : 'В корзину',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            ),
          ],
        ),
      ),
    ];
  }
}
