import 'package:flutter/material.dart';
import 'package:internet_market/shopModules/models/entities/product.dart';
import 'package:internet_market/shopModules/models/shoppingcart_model.dart';
import 'package:internet_market/shopModules/product_detail_page.dart';

class ProductGridItem extends StatefulWidget 
//rename to ProductGridView
{
  final Future<List<Product>> products;
  ProductGridItem({super.key, required this.products});
 
  @override
  State<StatefulWidget> createState() => ProductGridState();
}

class ProductGridState extends State<ProductGridItem> {
  int cartCount = 0;
  ShoppingCartModel shoppingCartModel = ShoppingCartModel();
  @override
  void initState() {
    super.initState();
    updateCartCount();
  }

  void updateCartCount() {
    setState(() {
      cartCount = shoppingCartModel.items.length;
    });
  }
  Widget buildGridItem(Product product) {
    return Card(
      child: Column(
        children: [
          if (product.imageUrl?.isNotEmpty ?? false)
            SizedBox(
              height: 100.0,
              width: double.infinity,
              child: Image.network(
                product.imageUrl!,
                fit: BoxFit.cover,
              ),
            )
          else
            const SizedBox(
              height: 100.0,
              width: double.infinity,
              child: Placeholder(),
            ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              product.title.toString(),
              style: const TextStyle(fontSize: 16.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Text(
              '${product.price} руб.',
              style: const TextStyle(fontSize: 14.0, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildProductGrid(List<Product> products) {
    //вытащить gridView.builder в ProductGridPage
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10.0,
        mainAxisSpacing: 10.0,
        childAspectRatio: 0.8,
      ),
      itemCount: products.length,
      itemBuilder: (context, index) {
        Product product = products[index];
        return InkWell(
          onTap: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProductDetailPage(product: product),
              ),
            );
            updateCartCount();
          },
          child: buildGridItem(product),
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Product>>(
      future: widget.products,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        } else if (snapshot.hasData) {
          List<Product> products = snapshot.data!;
          return buildProductGrid(products);
        } else {
          return const Center(child: Text('No products found'));
        }
      },
    );
  }
}