import 'package:flutter/material.dart';
import 'package:internet_market/shopModules/models/entities/category.dart';
import 'package:internet_market/shopModules/product_grid_page.dart';

class CategoryItem extends StatelessWidget {
  final Category category;
  const CategoryItem({super.key, required this.category});
  @override
  Widget build(BuildContext context) {
    return Card(    
          child: ListTile(
            tileColor: Colors.white,
            leading: Image.network(
              category.imageUrl!,
              width: 50,
              height: 50,
              fit: BoxFit.cover,
            ),
            title: Text(category.name!),
            onTap: () {
              // Проверяем, если название категории "laptop"
              if (category.name!.toLowerCase() == 'laptops') {
                // Переходим на страницу ProductView
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProductsView(),
                  ),
                );
              } else {
                // Иначе, вы можете обработать другие категории или ничего не делать
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Category ${category.name} selected')),
                );
              }
            },
          ),
        );
  }
  
}