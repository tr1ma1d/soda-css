import 'dart:developer';
import 'package:internet_market/core/api/api_service.dart';
import 'package:internet_market/shopModules/models/entities/product.dart';


class ProductsController {
    //  наследовать от BaseListModel

  // загрузку данных производим через переопределение метода  loadNextItems
  final ApiService apiService;

  ProductsController(this.apiService);

  Future<List<Product>> fetchProducts() async {
    const String endpoint = '/api/common/product/list';
    final Map<String, String> params = {
      'categoryId': '3972',
      'appKey': 'EyZ6DhtHN24DjRJofNZ7BijpNsAZ-TT1is4WbJb9DB7m83rNQCZ7US0LyUg5FCP4eoyUZXmM1z45hY5fIC-JTCgmqHgnfcevkQQpmxi8biwwlSn0zZedvlNh0QkP1-Um'
    };

    try {
      final response = await apiService.get(endpoint, params);

      if (response.containsKey('data')) {
        final data = response['data'] as List<dynamic>;
        final productList = data.map((item) => Product.fromJson(item)).toList();

        // Logging productList
        log('Products fetched: $productList');

        return productList;
      } else {
        throw Exception('Data key not found in response');
      }
    } catch (e) {
      log('Error in fetchProducts: $e');
      throw Exception('Failed to fetch products');
    }
  }
}
