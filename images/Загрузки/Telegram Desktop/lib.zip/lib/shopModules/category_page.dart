import 'package:flutter/material.dart';
import 'package:internet_market/shopModules/models/shoppingcart_model.dart';
import 'package:internet_market/shopModules/views/category_list_item.dart';
import 'package:provider/provider.dart';
import 'package:internet_market/shopModules/models/category_controller.dart';
import 'package:internet_market/shopModules/models/entities/category.dart';
import 'package:internet_market/shopModules/shopping_cart_page.dart';

class CategoryView extends StatefulWidget {
  //аналогичное поведение с ProductGridPage
  const CategoryView({super.key});

  @override
  _CategoryViewState createState() => _CategoryViewState();

}

class _CategoryViewState extends State<CategoryView> {
  List<Widget> buildActions() {
    return [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Stack(
          alignment: Alignment.center,
          children: [
            FloatingActionButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ShoppingCartPage(),
                  ),
                );
              },
              child: const Icon(
                Icons.shopping_cart,
                color: Colors.black,
              ),
            ),
            Positioned(
              right: 5,
              top: 5,
              child: Consumer<ShoppingCartModel>(
                builder: (context, cart, child) {
                  return CircleAvatar(
                    radius: 10,
                    backgroundColor: Colors.red,
                    child: Text(
                      cart.items.length.toString(),
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ];
  }

  final CategoryController controller = CategoryController();
 
  Widget buildList(BuildContext context, List<Category> categories) {
    return ListView.separated(
      itemCount: categories.length,
      separatorBuilder: (BuildContext context, int index) {
        return const SizedBox(height: 10);
      },
      itemBuilder: (context, index) {
        Category category = categories[index];
        return CategoryItem(category: category,);  
      },
    );

   }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: buildActions(),
        elevation: 1,
      ),
      body: Container(
        color: Colors.white24,
        child: FutureBuilder<List<Category>>(
          future: controller.getCategories(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('No data available'));
            } else {
              List<Category> categories = snapshot.data!;
              return buildList(context, categories);
              
            }
          },
        ),
      ),
    );
  }
}
