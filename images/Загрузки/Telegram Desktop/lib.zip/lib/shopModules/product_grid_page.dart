import 'package:flutter/material.dart';
import 'package:internet_market/core/api/api_service.dart';
import 'package:internet_market/shopModules/models/products_controller.dart';
import 'package:internet_market/shopModules/models/entities/product.dart';
import 'package:internet_market/shopModules/models/shoppingcart_model.dart';
import 'package:internet_market/shopModules/views/product_grid_item.dart';
import 'package:internet_market/shopModules/shopping_cart_page.dart';
import 'package:provider/provider.dart';

class ProductsView extends StatefulWidget {
  @override
  _ProductsViewState createState() => _ProductsViewState();
}

class _ProductsViewState extends State<ProductsView> {
  final ProductsController controller = ProductsController(ApiService('https://onlinestore.whitetigersoft.ru'));
  // Future<List<Product>>? _products;
  ShoppingCartModel shoppingCartModel = ShoppingCartModel();
  ProductsController pController = ProductsController(ApiService(""));
  int cartCount = 0;

  @override
  void initState() {
    super.initState();
    // _products = controller.fetchProducts();
    updateCartCount();
  }

  void updateCartCount() {
    setState(() {
      cartCount = shoppingCartModel.items.length;
    });
  }

  List<Widget> buildActions(BuildContext context) {
    return [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: FloatingActionButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const ShoppingCartPage(),
              ),
            );
          },
          child: const Icon(
            Icons.shopping_cart,
            color: Colors.black,
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Consumer<ShoppingCartModel>(
          builder: (context, cart, child) {
            return Text(
              cart.items.length.toString(),
              style: const TextStyle(color: Colors.black, fontSize: 18),
            );
          },
        ),
      ),
    ];
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text('Products'),
        actions: buildActions(context),
      ),
      //consumer<ProductsController>(
      body: ProductGridItem(products: _products!),
    );
  }
}