import 'package:internet_market/core/api/api_service.dart';
import 'package:internet_market/shopModules/models/entities/product.dart';

class ProductApi extends ApiService {
  ProductApi(super.baseUrl);

  Future<List<Product>> getProducts(int offset) async {
    var result = await get("////", {
      "offset": offset.toString(),
    });
    // парсим JSON в список продуктов
    return [];
  }

  Future<Product?> getProductById(int id) async {
    var result = await get("/////", {"productId": id.toString()  });
    // парсим JSON в экземпляр продукта
    return null;
  }
}
