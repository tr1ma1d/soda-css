import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:internet_market/shopModules/models/entities/product.dart';
import 'package:internet_market/shopModules/models/shoppingcart_model.dart';

class ShoppingCartPage extends StatefulWidget {
  const ShoppingCartPage({super.key});

  @override
  _StateCart createState() => _StateCart();
}

class _StateCart extends State<ShoppingCartPage> {
  void clearState() {
    // Implement your clear state logic here
    // Example:
    final cart = Provider.of<ShoppingCartModel>(context, listen: false);
    cart.buyProducts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Корзина'),
      ),
      body: Consumer<ShoppingCartModel>(
        builder: (context, cart, child) {
          return Column(
            children: [
              Expanded(
                child: cart.items.isEmpty
                    ? const Center(child: Text('Корзина пуста'))
                    : buildList(context, cart),
              ),
              buildButton(context),
            ],
          );
        },
      ),
    );
  }

  Widget buildList(BuildContext context, ShoppingCartModel cart) {
    return ListView.builder(
      padding: const EdgeInsets.only(top: 8.0),
      itemCount: cart.items.length,
      itemBuilder: (context, index) {
        Product product = cart.items[index];
        return Container(
          margin: const EdgeInsets.all(8.0),
          decoration: BoxDecoration(
            color: Colors.white10,
            borderRadius: BorderRadius.circular(20.0),
          ),
          child: ListTile(
            title: Text(product.title ?? 'No Title'),
            subtitle: Text('${product.price} руб.'),
            trailing: Text('Рейтинг: ${product.rating}'),
          ),
        );
      },
    );
  }

  Widget buildButton(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      alignment: Alignment.center,
      height: 50,
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.shopping_cart,
            color: Colors.black,
          ),
          const SizedBox(width: 8.0),
          ElevatedButton(
            onPressed: clearState,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.black,
            ),
            child: const Text(
              'Купить',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16.0,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
